-- phpMyAdmin SQL Dump
-- version 2.11.0
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 13, 2023 at 10:04 PM
-- Server version: 4.1.22
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `gestionvol`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(3) NOT NULL auto_increment,
  `Adresse_email` varchar(40) NOT NULL default '',
  `password` int(20) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `Adresse_email`, `password`) VALUES
(1, 'bellili@gmail.com', 0);

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(11) NOT NULL auto_increment,
  `Nom` varchar(50) default NULL,
  `Prenom` varchar(50) default NULL,
  `Adresse_email` varchar(100) default NULL,
  `cin` varchar(8) NOT NULL default '0',
  `Numero_telephone` varchar(15) default NULL,
  `mot` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `cin` (`cin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `Nom`, `Prenom`, `Adresse_email`, `cin`, `Numero_telephone`, `mot`) VALUES
(17, 'bellili', 'hamza', 'Bellilihamza952@gmail.com', '10258743', '9529338', '1234'),
(18, 'farhani', 'khalil', 'farhani@gmail.com', '11975823', '28154978', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `compagnie`
--

CREATE TABLE IF NOT EXISTS `compagnie` (
  `idcomp` varchar(20) NOT NULL default '',
  `nom` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`idcomp`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `compagnie`
--

INSERT INTO `compagnie` (`idcomp`, `nom`) VALUES
('2', 'nehli'),
('6', 'haway');

-- --------------------------------------------------------

--
-- Table structure for table `destination`
--

CREATE TABLE IF NOT EXISTS `destination` (
  `iddes` int(3) NOT NULL auto_increment,
  `country` varchar(30) NOT NULL default '',
  `state` varchar(30) NOT NULL default '',
  `date` varchar(20) NOT NULL default '0000-00-00',
  `nombre` int(11) NOT NULL default '0',
  `time` varchar(20) NOT NULL default '20:00:00',
  `image` varchar(20) NOT NULL default '',
  `idvol` int(3) NOT NULL default '0',
  PRIMARY KEY  (`iddes`),
  KEY `idvol` (`idvol`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `destination`
--

INSERT INTO `destination` (`iddes`, `country`, `state`, `date`, `nombre`, `time`, `image`, `idvol`) VALUES
(20, 'GERMANY', 'Berlin', '2023-12-16', 124, '01:30:00', 'destination_3', 9),
(21, 'SPAIN', 'Madrid', '2023-12-17', 1441, '20:15:00', 'destination_6', 11),
(22, 'ITALY', 'Rome', '2023-10-00', 121, '20:00:00', 'destination_2', 9),
(23, 'FRANCE', 'Paris', '2023-11-20', 187, '20:00:00', 'destination_5', 9),
(24, 'SUISSE', 'Bale', '2023-07-10', 168, '20:00:00', 'destination_4', 9),
(25, 'tunis', 'jerba', '2023-11-28', 113, '09:04', '', 9);

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE IF NOT EXISTS `reservations` (
  `ReservationID` int(3) NOT NULL auto_increment,
  `ClientID` int(11) NOT NULL default '0',
  `nombre` int(3) NOT NULL default '0',
  `DateReservation` date NOT NULL default '2023-01-02',
  `iddes` int(3) NOT NULL default '0',
  PRIMARY KEY  (`ReservationID`),
  KEY `ClientID` (`ClientID`),
  KEY `iddes` (`iddes`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`ReservationID`, `ClientID`, `nombre`, `DateReservation`, `iddes`) VALUES
(19, 17, 3, '2023-12-05', 21),
(21, 18, 2, '2023-12-12', 20),
(22, 18, 2, '2023-12-12', 21),
(23, 17, 2, '2023-12-12', 21),
(24, 17, 2, '2023-12-12', 21),
(25, 17, 2, '2023-12-12', 24),
(26, 17, 2, '2023-12-28', 20),
(27, 17, 6, '2023-12-12', 25),
(28, 17, 1, '2023-12-12', 25);

-- --------------------------------------------------------

--
-- Table structure for table `vol`
--

CREATE TABLE IF NOT EXISTS `vol` (
  `idvol` int(3) NOT NULL auto_increment,
  `idcomp` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`idvol`),
  KEY `fk_vol_compagnie` (`idcomp`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=14001 ;

--
-- Dumping data for table `vol`
--

INSERT INTO `vol` (`idvol`, `idcomp`) VALUES
(9, '2'),
(11, '2'),
(12, '2'),
(14, '2'),
(45, '2'),
(56, '2'),
(120, '2'),
(123, '2'),
(154, '2'),
(157, '2'),
(1234, '2'),
(14000, '6');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `destination`
--
ALTER TABLE `destination`
  ADD CONSTRAINT `destination_ibfk_1` FOREIGN KEY (`idvol`) REFERENCES `vol` (`idvol`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`ClientID`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `reservations_ibfk_2` FOREIGN KEY (`iddes`) REFERENCES `destination` (`iddes`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `vol`
--
ALTER TABLE `vol`
  ADD CONSTRAINT `fk_vol_compagnie` FOREIGN KEY (`idcomp`) REFERENCES `compagnie` (`idcomp`);
